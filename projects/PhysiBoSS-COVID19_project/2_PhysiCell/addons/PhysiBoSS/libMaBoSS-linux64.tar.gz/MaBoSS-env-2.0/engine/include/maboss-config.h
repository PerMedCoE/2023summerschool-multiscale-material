// @HAS_UNORDERED_MAP
#define HAS_UNORDERED_MAP
#include <unordered_map>
#define STATE_MAP std::unordered_map
#define HASH_STRUCT hash
